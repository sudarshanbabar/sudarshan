<?php
include 'header.php';
?>
<div class="image">
<img class="college-gif" src="images/my.gif" alt="college-gif">
<div class="centertext">There is no subtilte for hard work</div>
</div>
<div class="knowledge">
Where Knowledge is second nature
</div>
<div class="ourservices">
<div class="some">
Our Some Facilities
</div>
<div class="services">
<img src="images/library.jpg" alt="library">
<div class="textin">Large libraries with plenty books
</div>
</div>
<div class="services">
<img src="images/computer.jpg" alt="computer">
<div class="textin">Highend computer for programming
</div>
</div>
<div class="services">
<img src="images/sports.jpg" alt="sports">
<div class="textin">Motivational for sports
</div>
</div>
</div>
<?php
include 'footer.php';
?>
