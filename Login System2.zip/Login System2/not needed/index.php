<?php
	include_once 'header.php';
?>


<section class="main-container">
	<div class="main-wrapper">
		<h2>Railway Concession System</h2>
		<h3>Rules To Use This System :</h3>
		<h4>
			1.You Must Be The Student of A.C.Patil<br>
			2.Plz Enter Your Proper Details<br>
			3.Once You Register You Cannnot Alter The Details<br>
			4.Your Enter Details Will Be Use For Future <br>
			5.Enter Your Own PRN_No ( if you are trying to make fake registeration then your PRN_No will be block from this system and in future you will be unable to fill any Railway Concession Form )<br>
			6.Don't Share Your Password With Anyone
		</h4>
	</div>
</section>

<?php
	include_once 'footer.php';
?>
