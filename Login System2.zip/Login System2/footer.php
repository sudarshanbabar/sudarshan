<div class="footermain">
     <div class="footerimg">
        <img src="images/acpce-logo.png">
        <p>Our rich history is the foundation for our values. Join us to make your college experience unforgettable.</p>
    </div>
    <div class="mail">
         <div class="us">
            Get Social with us
        </div>
        <div class="media">
            <a href="#" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-twitter"></a>
            <a href="#" class="fa fa-google"></a>
            <a href="#" class="fa fa-linkedin"></a>
            <a href="#" class="fa fa-instagram"></a>
        </div>
    </div>
    <div class="aboutme">
        <h3>About Creators</h3><br>
        <p>Sudarshan Babar&nbsp;&nbsp;&nbsp;Roshan Badgujar&nbsp;&nbsp;&nbsp;Nikhil Chavan</p><br>
        <h4>"We Are Aspiring Computer Engineers With A Vision To Revolutionize The Field Of Technology"</h4>
    </div>
</div>
</body>
</html>